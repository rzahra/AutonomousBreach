init_breach_instances;
num_instances = 1; 
[Rl, pbs] = run_breach(B,R, num_instances);