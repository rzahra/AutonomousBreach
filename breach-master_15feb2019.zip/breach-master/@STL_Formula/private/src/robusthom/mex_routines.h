#include "mex.h"
#include "signal.h"

void writeSignal(const Signal &y, mxArray * mx_times, mxArray* mx_values);
