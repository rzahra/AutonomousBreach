function val = true_formula(traj,t) 
  
  val = inf;
 
