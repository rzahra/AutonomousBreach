classdef req_monitor < output_gen
    
    methods (Abstract)
         eval(this, t, X,p)
    end
    
end