clear;
InitBreach;

BrDemo.InitAFCparams;

warning('off', 'Simulink:LoadSave:EncodingMismatch')
mdl = 'mpcACCsystem';

BrAFC = BreachSimulinkSystem(mdl, 'all', [], {}, [], 'Verbose',0,'SimInModelsDataFolder', true); 


%alead_gen = pulse_signal_gen({'alead'}); % Generate a pulse signal for pedal angle
% alead_gen      = fixed_cp_signal_gen({'alead'}, ... % signal name
%                                        3,...                % number of control points
%                                       {'spline'});       % interpolation method 
%         
% %InputGen = BreachSignalGen({pedal_angle_gen, engine_gen});
% InputGen = BreachSignalGen({alead_gen});
% InputGen.SetParam({'alead_u0','alead_u1','alead_u2'},...
%                         [0.1 -0.1 0]);
% 
% %InputGen.SetParam({'alead_base_value', 'alead_pulse_period', ...
%  %                        'alead_pulse_amp','alead_pulse_width'}, ... 
%   %                       [0 30 -0.1 -.5]);
% 
% BrAFC.SetInputGen(InputGen);
              % Creates a copy of the system interface 
input_gen.type = 'VarStep';                % uniform time steps 
input_gen.cp = [2];                      % number of control points
input_gen.method = {'previous'};  % interpolation methods - see help of interp1.
BrAFC.SetInputGen(input_gen); 

%%
% This creates a new input parameterization:
BrAFC.PrintParams();
BrAFC.PrintSignals();

%% Changing Input Functions
% We set values for the control points and plot the result. The 
% semantics is input_ui holds for input_dti seconds 
%BrAFC.SetParam({'alead_u0','alead_dt0','alead_u1', 'alead_dt1', 'alead_u2'},...
 %                    [ 0.1 10 -0.1 30 0]);
BrAFC.SetParam({'alead_u0','alead_dt0','alead_u1'},...
                     [0.1 7.5 -0.1]);
% %AFC_VarStep.SetParam({'Pedal_Angle_u0','Pedal_Angle_dt0','Pedal_Angle_u1'}, [20 15 60]);
%BrAFC.Sim(0:.01:15);
%figure; BrAFC.PlotSignals({'dmin','drel','alead'});
