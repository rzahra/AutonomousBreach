function sz = Psize_pts(P)
    
    sz = size(P.pts,2);
