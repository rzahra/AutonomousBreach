function [B, allProps, allSimulationTimes] = getATSystemAndSpecs()
% GETATSYSTEMANDSPECS Get AT benchmark system and specifications
%   This function creates a BreachSimulinkSystem and also a cell array with
%   specifications to falsify for the Automatic Transmission benchmark
%   model. 
%
%   B is the BreachSimulinkSystem object that is used by Breach to simulate
%       the AT system. The model that is being simulated is
%       'autotrans_mod4.mdl'. 
%   allProps is a cell array with STL_Formula objects that will be used
%       for falsification. Note that there are different entries in
%       allProps when the same specification has two different parameter
%       values. 
%   allSimulationTimes is a vector that specifies which simulation end
%       time to use for each specification in propsToUse. 

% Initialize variables
allProps = {};
allSimulationTimes = [];

%%%%%%%%%
% phi_1 %
%%%%%%%%%
allProps{1} = STL_Formula('Problem1', 'alw (Out5[t]-Out4[t]<=40)');
allSimulationTimes(1) = 20; % Can be changed

%%%%%%%%%
% phi_2 %
%%%%%%%%%
allProps{2} = STL_Formula('Problem2', 'alw_[0, 30](ev_[0,10](RPM[t] <= 3500 or RPM[t] >= 4500))');
allSimulationTimes(2) = 30;

%%%%%%%%%
% phi_3 %
%%%%%%%%%
allProps{3} = STL_Formula('Problem3', 'alw_[0,80] ((alw_[0,20] Out2[t]-Out1[t]<=20) or (ev_[0,20] Out5[t]-Out4[t]>=40))');
allSimulationTimes(3) = 80;

%%%%%%%%%
% phi_4 %
%%%%%%%%%

allProps{4} = STL_Formula('Problem4', 'alw_[0,65] ev_[0,30] alw_[0,5] (Out5[t]-Out4[t]>=8)');
allSimulationTimes(4) = 80;

%%%%%%%%%
% phi_5 %
%%%%%%%%%

allProps{5} = STL_Formula('Problem5', 'alw_[0,72] ev_[0,8] (alw_[0,5] (Out2[t]-Out1[t]>=9) => alw_[5,20] (Out5[t]-Out4[t]>= 9))');
allSimulationTimes(5) = 80;



% Create the BreachSimulinkSystem object
B = BreachSimulinkSystem('cars');


%% Input Specification
B.SetInputGen('UniStep4');
Inputs = B0.GetInputParamList();
B.SetParamRanges(Inputs, [0 1.]);


%% Note: It can be runned by UniStep20.

end

