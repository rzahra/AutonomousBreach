init_breach_instances
num_instances= 1; 
[Rlogs1, pbs1] = run_breach(B1, Rs, num_instances);
[Rlogs2, pbs2] = run_breach(B2, Rs, num_instances);