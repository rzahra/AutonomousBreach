function [B, allProps, allSimulationTimes] = getATSystemAndSpecs()
% GETATSYSTEMANDSPECS Get AT benchmark system and specifications
%   This function creates a BreachSimulinkSystem and also a cell array with
%   specifications to falsify for the Automatic Transmission benchmark
%   model. 
%
%   B is the BreachSimulinkSystem object that is used by Breach to simulate
%       the AT system. The model that is being simulated is
%       'autotrans_mod4.mdl'. 
%   allProps is a cell array with STL_Formula objects that will be used
%       for falsification. Note that there are different entries in
%       allProps when the same specification has two different parameter
%       values. 
%   allSimulationTimes is a vector that specifies which simulation end
%       time to use for each specification in propsToUse. 

% Initialize variables
u_ts = 0.001;
allProps = {};
allSimulationTimes = [];

%%%%%%%%%
% phi_1 %
%%%%%%%%%
% alph=0.005, bet=0.03

string1 = 'abs(Pos[t] - Ref[t]) < 0.005 + 0.03 * abs(Ref[t])';
string2 = 'ev_[0, 2] (alw_[0, 1] (close_ref)';
allProps{1} = STL_Formula('Problem1', ['( alw_[1, 37] (( not' string1 ' ) =>' string2 ')']);
allSimulationTimes(1) = 40;


%%%%%%%%%
% phi_2 %
%%%%%%%%%
% alph=0.005, bet=0.04

string1 = 'abs(Pos[t] - Ref[t]) < 0.005 + 0.04 * abs(Ref[t])';
string2 = 'ev_[0, 2] (alw_[0, 1] (close_ref)';
allProps{2} = STL_Formula('Problem2', ['( alw_[1, 37] (( not' string1 ' ) =>' string2 ')']);
allSimulationTimes(2) = 40;


%%%%%%%%%
% phi_3 %
%%%%%%%%%
% alph=0.005, bet=0.04

string1 = 'abs(Pos[t] - Ref[t]) < 0.005 + 0.04 * abs(Ref[t])';
string2 = 'ev_[0, 2] (alw_[0, 1] (close_ref)';
allProps{3} = STL_Formula('Problem3', ['( alw_[1, 37] (( not' string1 ' ) =>' string2 ')']);
allSimulationTimes(3) = 40;

% Create the BreachSimulinkSystem object
B = BreachSimulinkSystem('narmamaglev_v1');

% Number of control points: how many?
B.SetInputGen('UniStep3');
InputParams = B.GetInputParamList();
B.SetParamRanges(InputParams, [1 3]);

%% Note: It can be done with UniStep12

end