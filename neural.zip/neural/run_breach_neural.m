init_breach_instances;
num_instances =1; 

%%
[Rls1, pbs1] = run_breach(B1, Rbeta3,1);

%%
[Rls2, pbs2] = run_breach(B2, Rbeta3,1);