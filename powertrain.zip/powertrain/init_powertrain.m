simTime        = 50;
measureTime    =  1;
fault_time     = 60;
spec_num       =  1;
fuel_inj_tol   =  1;
MAF_sensor_tol =  1;
AF_sensor_tol  =  1;