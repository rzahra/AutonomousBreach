init_breach_instances
num_instances=1;
%%
[Rl1, pbs1] = run_breach(B1, Rs,num_instances);

%%
[Rl2, pbs2] = run_breach(B2, Rs, num_instances);