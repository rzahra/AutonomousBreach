init_breach_instances;
num_instances = 10;
%%
[Rl, pbs ] =  run_breach(B0, Rs,num_instances);