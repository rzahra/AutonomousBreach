% function y = deg2rad(u)
% converts degrees into radians
function y = deg2rad(u)
y = u * pi/180;
