% Function y = rad2deg(u)
% converts radians to degrees
function y = rad2deg(u)

y = u * 180/pi;
