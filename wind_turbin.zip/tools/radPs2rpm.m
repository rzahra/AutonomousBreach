% function y = radPs2rmp(u)
% converts rad/s to rmp
function y = radPs2rpm(u)
y = u * 60/(2*pi);
