% function y = rmp2radPs(u)
% converts rmp to rad/s
function y = rpm2radPs(u)
y = u * 2*pi/60;
